
public class Main {

	public static void main(String[] args) {
		
		String[] strings = {"Welcome!"};
		System.out.println(strings[1]);

	}

}
