package com.lynda.olivepress.press;

import java.util.Collection;

import com.lynda.olivepress.olives.Olive;

public class OlivePress2 implements Press {

	@Override
	public void getOil(Collection<Olive> olives) {
		// TODO Auto-generated method stub

	}

	@Override
	public int getTotalOil() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setTotalOil(int totalOil) {
		// TODO Auto-generated method stub

	}

}
