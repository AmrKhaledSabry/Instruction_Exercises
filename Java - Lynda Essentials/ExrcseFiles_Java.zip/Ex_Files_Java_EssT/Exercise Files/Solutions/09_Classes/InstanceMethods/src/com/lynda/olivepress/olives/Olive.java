package com.lynda.olivepress.olives;

public class Olive {
	
	public void crush() {
		System.out.println("ouch!");
	}

}
