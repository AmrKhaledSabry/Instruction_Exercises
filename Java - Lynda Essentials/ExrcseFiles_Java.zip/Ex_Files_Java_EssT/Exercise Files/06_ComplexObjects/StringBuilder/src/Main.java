
public class Main {

	public static void main(String[] args) {
		String s1 = "Welcome";
	}

}
