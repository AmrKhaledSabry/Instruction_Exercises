package com.lynda.files;

public class CopyFile {

	public static void main(String[] args) {

	}
}
