package com.lynda.files;

public class ReadNetworkFile {

	public static void main(String[] args) {

	}

}
