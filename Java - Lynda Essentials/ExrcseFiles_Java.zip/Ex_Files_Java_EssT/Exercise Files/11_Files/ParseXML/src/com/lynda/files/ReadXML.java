package com.lynda.files;

public class ReadXML {

	public static void main(String[] args) {
	
	}

}
